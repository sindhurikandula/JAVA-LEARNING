package accountTest;

import accountexceptions.*;
import accountvariants.*;

public class Testing {

	public static void main(String[] args) {
		
		try {
			BankAccount b1=new BankAccount(101,"sindhuri",-23);
			System.out.println("b1:"+b1);
		} 
		catch (AcctNoInvalidException | ActNameInvalidException | AcctBalInvalidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			System.out.println("bound to be called regardless of the exceptions....");
		}
		
		
		try {
			SavingsAccount sb1=new SavingsAccount(102,"Shanvi",30000,4.5);
			System.out.println("sb1:"+sb1);
			
		} catch (AcctNoInvalidException | ActNameInvalidException | AcctBalInvalidException
				| RateOfIntrstInvalidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			FIxedDepositAccount fd=new FIxedDepositAccount(103,"Jacky",30000,5.6,0);
			System.out.println("fd:"+fd);
			
		} catch (AcctNoInvalidException | ActNameInvalidException | AcctBalInvalidException
				| RateOfIntrstInvalidException | InvalidFDTenureException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			CreditCardAccount cc=new CreditCardAccount(105,"shany",3000);
			
		} catch (AcctNoInvalidException | ActNameInvalidException | AcctBalInvalidException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
