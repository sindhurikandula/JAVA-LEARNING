package accountexceptions;

public class AcctNoInvalidException extends Exception
{

	public AcctNoInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
