package accountexceptions;

public class AcctBalInvalidException extends Exception {

	public AcctBalInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
