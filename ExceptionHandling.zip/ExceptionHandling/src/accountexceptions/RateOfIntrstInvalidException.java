package accountexceptions;

public class RateOfIntrstInvalidException extends Exception {

	public RateOfIntrstInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
