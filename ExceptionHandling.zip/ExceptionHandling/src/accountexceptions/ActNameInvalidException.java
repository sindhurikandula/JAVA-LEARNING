package accountexceptions;

public class ActNameInvalidException extends Exception {

	public ActNameInvalidException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
