package accountexceptions;

public class CreditLimitExceededException extends RuntimeException {

	public CreditLimitExceededException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
