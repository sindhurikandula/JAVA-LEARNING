package accountexceptions;

public class InvalidFDTenureException extends Exception {

	public InvalidFDTenureException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
