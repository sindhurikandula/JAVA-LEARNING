package accountvariants;

import accountexceptions.*;

public class SavingsAccount extends BankAccount {
	protected double rateOfIntrst;

	public SavingsAccount(int x, String s, double y, double r) throws AcctNoInvalidException, ActNameInvalidException, AcctBalInvalidException, RateOfIntrstInvalidException
	{
		super(x, s, y);

		System.out.println("constructor for savings bank account is invoked");

		if (r <=0)
			throw new RateOfIntrstInvalidException("Rate of Interest cannot be negative or null...terminating...");
		else
			rateOfIntrst = r;
	}
    
	
	@Override
	public String toString() {
		return "SavingsAccount [rateOfIntrst=" + rateOfIntrst + ", accountBalance=" + accountBalance + "]";
	}


	double simpleIntCal() {
		return ((accountBalance * rateOfIntrst) / 100);
	}

}



