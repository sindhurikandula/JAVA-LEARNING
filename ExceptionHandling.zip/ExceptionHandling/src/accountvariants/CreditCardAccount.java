package accountvariants;

import accountexceptions.*;

public class CreditCardAccount extends BankAccount {

	double creditLimit;

	public CreditCardAccount(int x, String s, double y) throws AcctNoInvalidException, ActNameInvalidException, AcctBalInvalidException {
		super(x, s, y);
		System.out.println("constructor for credit card is invoked");

	}


	double CreditLimitCal() {

		if (accountBalance > 200000) {
			creditLimit = 0.3 * accountBalance;
			System.out.println("credit limit is " + creditLimit);
		}
		if (accountBalance > 100000 && accountBalance <=200000) {
			creditLimit = 0.2 * accountBalance;
			System.out.println("credit limit is " + creditLimit);
		} else {
			creditLimit = 0;
			System.out.println("credit card cannot be issued");
		}
		return creditLimit;
	}
	
	@Override
	public String toString() {
		return "CreditCardAccount [creditLimit=" + creditLimit + ", accountBalance=" + accountBalance + "]";
	}

	
	double withdrawCredit(double amtToWithdraw)
	{
		System.out.println("withdrawl is in progress" + amtToWithdraw);
		if(amtToWithdraw<creditLimit)
		{	
			creditLimit = creditLimit - amtToWithdraw;
		System.out.println("withdrawl completed..." + amtToWithdraw);
		}
		else
			throw new CreditLimitExceededException("credit limit exceeded....amt cannot be withdrawn");
		
		return creditLimit;
	}
}
