package accountvariants;

import accountexceptions.*;

public class BankAccount {

	private int accountNumber;
	private String accountHolderName;
	protected double accountBalance;

	public BankAccount(int x, String y, double z) throws AcctNoInvalidException, ActNameInvalidException, AcctBalInvalidException {

		System.out.println("constructor for bank account is invoked");

		if (x <= 0)
			throw new AcctNoInvalidException("Account number cannot be negative..terminating...");
		else
			accountNumber = x;

		if (validateName(y))
			accountHolderName = y;

		else

			throw new ActNameInvalidException("Invalid acct holder name...terminating...");

		if (z < 0)
			throw new AcctBalInvalidException("Account balance cannot be negative...terminating...");
		else
			accountBalance = z;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName
				+ ", accountBalance=" + accountBalance + "]";
	}

	private static boolean validateName(String str) {
		return ((!str.equals("")) && (str != null) && (str.matches("^[a-zA-Z]*$")));
	}

}
