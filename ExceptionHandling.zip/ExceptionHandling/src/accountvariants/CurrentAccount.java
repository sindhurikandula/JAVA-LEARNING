package accountvariants;

public class CurrentAccount {

}
