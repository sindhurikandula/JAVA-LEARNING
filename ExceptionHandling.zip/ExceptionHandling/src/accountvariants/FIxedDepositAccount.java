package accountvariants;
import accountexceptions.*;

public class FIxedDepositAccount extends SavingsAccount {
	
	private int tenure;

	public FIxedDepositAccount(int x, String s, double y, double r,int t) throws AcctNoInvalidException,
			ActNameInvalidException, AcctBalInvalidException, RateOfIntrstInvalidException, InvalidFDTenureException {
		super(x, s, y, r);
		
		System.out.println("constructor for fixed deposit  is invoked");

		if (t <=0)
			throw new InvalidFDTenureException("Tenure cannot be negative or null......terminating...");
		else
			tenure = t;
	
	}
	

	@Override
	public String toString() {
		return "FIxedDepositAccount [tenure=" + tenure + ", rateOfIntrst=" + rateOfIntrst + ", accountBalance="
				+ accountBalance + "]";
	}


	double maturityAmtCal() {

		double x = Math.pow(1 + (rateOfIntrst / 100), tenure);
		double ma = accountBalance * x;
		return ma;
	}

}



