package com.sbi.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Account;

@Service
public interface AccountService {
	
	List<Account> findAllAccountsService();
	 Account findAccountByIdService(int accno);
	 void insertAccountService(Account acct);
	 void updateAccountService(Account acct);
	 void deleteAccountService(int accno);


}
