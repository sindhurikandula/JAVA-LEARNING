package com.sbi.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Payee;
import com.sbi.demo.repositories.PayeeRepository;

@Service
public class PayeeServiceImpl implements PayeeService {
	
	
	@Autowired
	PayeeRepository payeeReps;

	@Override
	public List<Payee> findAllPayeesService() {
		
		List<Payee> payeeList=payeeReps.findAllPayees();
		return payeeList;
	}

	@Override
	public Payee findPayeeByIdService(int payeeId) {
		
		return payeeReps.findPayeeById(payeeId);
	}

	@Override
	public void insertPayeeService(Payee payee) {
		
		 payeeReps.insertPayee(payee);
	}

	@Override
	public void updatePayeeService(Payee payee) {
		
		payeeReps.updatePayee(payee);
	}

	@Override
	public void deletePayeeService(int payeeId) {
		
		payeeReps.deletePayee(payeeId);
	}

}
