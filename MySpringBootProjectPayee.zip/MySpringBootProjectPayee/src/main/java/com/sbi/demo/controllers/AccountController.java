package com.sbi.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sbi.demo.entity.Account;
import com.sbi.demo.services.AccountService;

@RestController
@RequestMapping("/accts")
public class AccountController {
	
	@Autowired
	AccountService acctService;
	
	
	@RequestMapping("/")
	public List<Account> allAccts()
	{
		return acctService.findAllAccountsService();
	}
	
	@RequestMapping("/{accno}")
	public Account getSingleAcct(@PathVariable("accno") int x)
	{
		return acctService.findAccountByIdService(x);
	}
	
	@PostMapping("/addAcct")
	public void insertAcct(@RequestBody Account acct)
	{
		acctService.insertAccountService(acct);
	}
	
	@PutMapping("/updateAcct")
	public void updateAcct(@RequestBody Account acct)
	{
		acctService.updateAccountService(acct);
	}
	
	@DeleteMapping("/deleteAcct/{x}")
	public void deleteDepartmentt(@PathVariable("x") int accNoToBeDeleted)
	{
		acctService.deleteAccountService(accNoToBeDeleted);
	}
	

}
