package com.sbi.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.sbi.demo.entity.*;
import com.sbi.demo.services.*;

@CrossOrigin
@RestController
@RequestMapping("/payee")
public class AccountPayeeController {

	
	@Autowired
	AccountPayeeService aps;

	@RequestMapping("/{accno}")                                    
	public List<Payee> getPayeesOfSingleAcct(@PathVariable("accno") int x)   //http://localhost:8080/payee/101
	{
		return aps.viewPayeesOfThisAccountNUmber(x);
	}
	
	@PostMapping("/addPayee/{accno}")
	public void insertPayee(@PathVariable("accno") int acno, @RequestBody Payee payee)
	{
		aps.insertPayeeIntoThisAccountNumber(acno, payee);
	}
	
	@PutMapping("/updatePayee/{x}/{y}/{z}")
	public void updatePayee(@PathVariable("x") int accno,@PathVariable("y") int pid,@PathVariable("z") int newLimit)
	{
		aps.upgradeTransferLimitOfAPayee(accno, pid, newLimit);
	}
	
	@DeleteMapping("/deletePayee/{x}/{y}")
	public void deletePayee(@PathVariable("x") int accFromwhichPayeeToBeDeleted,@PathVariable("y") int payeeToBeDeleted)
	{
	    aps.deletePayeeOfThisAccountNumber(accFromwhichPayeeToBeDeleted, payeeToBeDeleted);
	}
}
