package com.sbi.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Account;
import com.sbi.demo.repositories.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	AccountRepository acctReps;
	

	@Override
	public List<Account> findAllAccountsService() {
		
		List<Account> acctList=acctReps.findAllAccounts();
		return acctList;
	}

	@Override
	public Account findAccountByIdService(int accno) {
		
		return acctReps.findAccountById(accno);
	}

	@Override
	public void insertAccountService(Account acct) {
		
		acctReps.insertAccount(acct);
	}

	@Override
	public void updateAccountService(Account acct) {
		
		acctReps.updateAccount(acct);
	}

	@Override
	public void deleteAccountService(int accno) {
		
	acctReps.deleteAccount(accno);
	  	
	}

}
