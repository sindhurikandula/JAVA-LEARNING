package com.sbi.demo.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Payee;


@Repository
public class PayeeRepositoryImpl implements PayeeRepository {
	
	
	@PersistenceContext
	
	EntityManager em;

	@Override
	public List<Payee> findAllPayees() {
      
		TypedQuery<Payee> q=em.createQuery("from Payee",Payee.class);
		return q.getResultList();
	}

	@Override
	public Payee findPayeeById(int payeeId) {
		
		return em.find(Payee.class, payeeId);
	}

	@Override
	@Transactional
	public void insertPayee(Payee payee) {
	
		em.persist(payee);
		
	}

	@Override
	@Transactional
	public void updatePayee(Payee payee) {
		
		em.merge(payee);
	}

	@Override
	@Transactional
	public void deletePayee(int payeeId) {

		Payee a=em.find(Payee.class, payeeId);

		em.remove(a);
	
		
		
	}

}
