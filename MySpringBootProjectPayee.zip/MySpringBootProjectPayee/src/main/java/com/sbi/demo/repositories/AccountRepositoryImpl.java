package com.sbi.demo.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Account;


@Repository
public class AccountRepositoryImpl implements AccountRepository {
	
	
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Account> findAllAccounts() {
	
		TypedQuery<Account> q=em.createQuery("from Account",Account.class);
		return q.getResultList();
	}

	@Override
	public Account findAccountById(int accno) {
	
		return em.find(Account.class,accno);
	}

	@Override
	@Transactional
	public void insertAccount(Account acct) {
		em.persist(acct);
		
	}

	@Override
	@Transactional
	public void updateAccount(Account acct) {
		
		em.merge(acct);
	}

	@Override
	@Transactional
	public void deleteAccount(int accno) {
	
		Account a=em.find(Account.class, accno);
		em.remove(a);
		
	}

}
