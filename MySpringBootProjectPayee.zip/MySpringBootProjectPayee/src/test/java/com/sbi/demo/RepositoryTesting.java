package com.sbi.demo;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.demo.entity.Account;
import com.sbi.demo.entity.Payee;
import com.sbi.demo.repositories.*;


@SpringBootTest
public class RepositoryTesting {

	@Autowired
	AccountRepository acctReps;
	
	@Test
	public void allaccountsTest()
	{
	
			List<Account> acctList = acctReps.findAllAccounts();
			for (Account acct : acctList)
			{
				System.out.println("ACCTNO : "+acct.getAcctNo());
				System.out.println("ACCTNAME : "+acct.getAcctName());
				System.out.println("ACCTMAILID: "+acct.getMailId());
				System.out.println("ACCTBAL: "+acct.getAccBal());
				System.out.println("USERNAME : "+acct.getUsername());
				System.out.println("PASSWORD : "+acct.getPassword());
				System.out.println("----------------------------------");
			}
			
		}
	
	@Test
	public void accountById()
	{
		Account acct=acctReps.findAccountById(101);
		System.out.println("ACCTNO : "+acct.getAcctNo());
		System.out.println("ACCTNAME : "+acct.getAcctName());
		System.out.println("ACCTMAILID: "+acct.getMailId());
		System.out.println("ACCTBAL: "+acct.getAccBal());
		System.out.println("USERNAME : "+acct.getUsername());
		System.out.println("PASSWORD : "+acct.getPassword());
		System.out.println("----------------------------------");
		
	}
	
	@Test
	public void insertAccount()
	{
		Account acct=new Account();
		acct.setAccBal(25000);
		acct.setAcctName("vardhan");
		acct.setAcctNo(105);
		acct.setMailId("vardhan1@gmail.com");
		acct.setUsername("vardhan1");
		acct.setPassword("vardhan@1");
		
		acctReps.insertAccount(acct);
		
	}
	
	@Test
	public void updateAccount()
	{
	  Account acct=acctReps.findAccountById(101);
		acct.setAccBal(50000);
		acct.setAcctName("Keshav");
		acct.setAcctNo(103);
		acct.setMailId("Keshav@gmail.com");
		acct.setUsername("Keshav12");
		acct.setPassword("Keshav@1");
		
		acctReps.updateAccount(acct);
		
		
	}
	
	
	@Test
	public void deleteAccount()
	{
	    acctReps.deleteAccount(105);
	}
	
	@Autowired
	PayeeRepository payeeReps;
	
	@Test
	public void allPayeesTest()
	{
	
			List<Payee> payeeList = payeeReps.findAllPayees();
			for (Payee p : payeeList)
			{
				System.out.println("PAYEE ACCTNO : "+p.getPayeeAcctNo());
				System.out.println("PAYEE ID : "+p.getPayeeId());
				System.out.println("LIMIT: "+p.getPayeeLimit());
				System.out.println("PAYEE NAME: "+p.getPayeeName());
				System.out.println("PAYEE NICK NAME : "+p.getPayeeNickName());
				System.out.println("USER ACCOUNT : "+p.getAccount().getAcctNo());
				System.out.println("----------------------------------");
			
		}
	}			
	
	@Test
	public void PayeeById()
	{
		Payee p=payeeReps.findPayeeById(1);
		System.out.println("PAYEE ACCTNO : "+p.getPayeeAcctNo());
		System.out.println("PAYEE ID : "+p.getPayeeId());
		System.out.println("LIMIT: "+p.getPayeeLimit());
		System.out.println("PAYEE NAME: "+p.getPayeeName());
		System.out.println("PAYEE NICK NAME : "+p.getPayeeNickName());
		System.out.println("USER ACCOUNT : "+p.getAccount().getAcctNo());
		System.out.println("----------------------------------");
		
	}
	
	@Test
	public void insertPayee()
	{  
		Account a=acctReps.findAccountById(101);
		Payee p=new Payee();
		p.setPayeeId(3);
		p.setPayeeAcctNo(104);
		p.setPayeeLimit(50000);
		p.setPayeeName("Vardhan");
		p.setPayeeNickName("Hubby");
		p.setAccount(a);
		
		payeeReps.insertPayee(p);
		
	}	
		
	
	
	@Test
	public void updatePayee()
	{
		Payee p=new Payee();
		Account a=acctReps.findAccountById(101);
		p.setPayeeId(3);
		p.setPayeeAcctNo(104);
	    p.setPayeeLimit(10000);
	    p.setPayeeNickName("BBaby");
	    p.setPayeeName("VVardhan");
		p.setAccount(a);
		
       payeeReps.updatePayee(p);
		
		
	}
	
	
	@Test
	public void deletePayeeTest()
	{
	    payeeReps.deletePayee(3);
	}
	
//	@Test
//	public void deletePayeeByAccountAndPayeeIdTest()
//	{
//	    acctReps.deletePayeeOfThisAccountNumber(101, 1);
//	}
	
}
