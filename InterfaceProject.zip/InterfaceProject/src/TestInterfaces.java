
public class TestInterfaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

abstract class x {
	void fun1() {
	}

	void fun2() {
	}

	void fun3() {
	}

	void fun4() {
	}

	void fun5() {
	}
abstract void fun();
	
}

class y extends x {
	void fun6() {
	}

	void fun7() {
	}

	void fun8() {
	}

	void fun9() {
	}

	void fun10() {
	}

	@Override
	void fun() {
		// TODO Auto-generated method stub
		
	}
}

interface A {
	void Afun1();

	void Afun2();

	void Afun3();
}

interface B extends A {
	void Bfun1();

	void Bfun2();

	void Bfun3();

	void Bfun4();

	void Bfun5();
}

interface P {
	void Pfun1();

	void Pfun2();

	void Pfun3();

	void Pfun4();

	void Pfun5();
}

interface Q extends P {
	void Qfun1();

	void Qfun2();

	void Qfun3();

	void Qfun4();

	void Qfun5();
}

interface R extends Q {
	void Rfun1();

	void Rfun2();

	void Rfun3();

	void Rfun4();

	void Rfun5();
}

class z extends y implements B, R 
{

	@Override
	public void Afun1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Afun2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Afun3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Qfun1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Qfun2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Qfun3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Qfun4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Qfun5() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Pfun1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Pfun2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Pfun3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Pfun4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Pfun5() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Rfun1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Rfun2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Rfun3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Rfun4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Rfun5() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Bfun1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Bfun2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Bfun3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Bfun4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Bfun5() {
		// TODO Auto-generated method stub
		
	}

}