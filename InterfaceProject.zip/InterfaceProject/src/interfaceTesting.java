
public class interfaceTesting {

	public static void main(String[] args) {
	/*	//Area a=new Area();we cannot create instances/objects of interface
		Area a=new GeometricalShape();//to access methods of interface area
		a.calcArea();
		
		Perimeter p=new GeometricalShape();//to access methods of interface perimeter
		p.calcPerimeter();
		
		GeometricalShape gs=new GeometricalShape();//to access methods of interface area,perimeter and explicit methods of geometrical shape class
		gs.Properties();
		gs.calcArea();
		gs.calcPerimeter();
		
		side s=new Triangle();//to access methods of interface side
		s.threeSides();
		
		Triangle t=new Triangle();//we can access all methods 
		t.calcArea();
		t.calcPerimeter();
		t.Properties();
		t.threeSides();*/
			
		fun.fun1(new EquilateralTriangle());
	}

}

class fun
{
	static void fun1(Area x)
	{
		x.calcArea();
		
		if(x instanceof EquilateralTriangle) {
		} EquilateralTriangle et = (EquilateralTriangle)x;
		
		et.equalSides();
		et.calcPerimeter();
	}
	
	static void fun2(side s)
	{
		s.threeSides();
	}
	
	
}

interface Area
{
	void calcArea();
}
interface Perimeter
{
	void calcPerimeter();
}

class GeometricalShape implements Area,Perimeter
{

	@Override
	public void calcPerimeter() {
		System.out.println("calculate perimeter");
		
		
	}

	@Override
	public void calcArea() {
		System.out.println("calculate area");
		
		
	}
   
	void Properties()//explicit method
	{
		System.out.println("geometrical shape will have some properties");
	}
	
}

interface side
{
	void threeSides();
}

class Triangle extends GeometricalShape implements side
{

	@Override
	public void threeSides() {
	System.out.println("no of sides are 3 for triangle");
		
	}
	
}

class EquilateralTriangle extends Triangle
{
	 void equalSides()
	 {
		 System.out.println("All the sides to be equal");
	 }
}

