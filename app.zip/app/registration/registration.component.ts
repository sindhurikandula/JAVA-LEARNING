import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor() {
console.log('Registration component constructor called...');
   }

  ngOnInit(): void {
console.log('Registration component:ngOnInit() called');

  }

  title = 'Registration';

}
