import { Component, OnInit } from '@angular/core';
import { BankApplicant } from './BankApplicant';

@Component({
  selector: 'app-bank-applicant',
  templateUrl: './bank-applicant.component.html',
  styleUrls: ['./bank-applicant.component.css']
})
export class BankApplicantComponent implements OnInit {

bankApp:BankApplicant=new BankApplicant();

deptObj:Dept=new Dept();

deptAry: Dept[] = [
  {"deptno":10,"dname":"Accounting","loc":"New York","empList":[
    {"empno":7839,"ename":"King","salary":5000,"epic":"/assets/Modi.jpg"},
    {"empno":7782,"ename":"Clark","salary":2450,"epic":"/assets/Virat.jpg"},
    {"empno":7934,"ename":"Miller","salary":1300,"epic":""}
  ]
  },
  {"deptno":20,"dname":"Research","loc":"New Jersey","empList":[
    {"empno":7566,"ename":"Jones","salary":2975,"epic":"/assets/Kalpana.jpg"},
    {"empno":7902,"ename":"Ford","salary":3000,"epic":""},
    {"empno":7369,"ename":"Smith","salary":800,"epic":""},
    {"empno":7788,"ename":"scott","salary":3000,"epic":""},
    {"empno":7876,"ename":"Adams","salary":1100,"epic":""}
  ]
},
  {"deptno":30,"dname":"Sales","loc":"Dallas","empList":[
    {"empno":7698,"ename":"blake","salary":2975,"epic":""},
    {"empno":7654,"ename":"Martin","salary":3000,"epic":""},
    {"empno":7499,"ename":"Allen","salary":800,"epic":""},
    {"empno":7844,"ename":"Turner","salary":3000,"epic":""},
    {"empno":7900,"ename":"James","salary":1100,"epic":""},
    {"empno":7521,"ename":"Ward","salary":1100,"epic":""}
  ]
 },
  {"deptno":40,"dname":"Operations","loc":"Bostons","empList":[]},
  {"deptno":50,"dname":"Purchase","loc":"Washington","empList":[]},
  {"deptno":60,"dname":"QMS","loc":"London","empList":[]},
  {"deptno":70,"dname":"Testing","loc":"Pune","empList":[]}

];


addDeptToArray()

{
   this.deptAry.push(this.deptObj);
}

deleteDeptFromArray(obj:Dept)
{
  this.deptAry =  this.deptAry.filter(item => item!= obj);

}



  constructor() { }

  ngOnInit(): void {
    
  }

  
}
class Dept {
  deptno!: number;
  dname!: string;
  loc!:string; 

  empList: Emp[] = [];
  
}

class Emp
{
  empno!:number;
  ename!:String;
  salary!:number;
  epic!:String;
}