export class BankApplicant
{   
    applicantId!:number;
    applicantName!:string;
    applicantMobile!:string;
    birthdate!:Date;
    emailAddress!:string;
    permaddress!:string;
    accountAppliedFor!:string;
    panCard!:string;
    annualIncome!:number;
    applicantStatus!:string;
}