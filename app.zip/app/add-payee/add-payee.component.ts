import { Component, OnInit } from '@angular/core';
import { PayeeserviceService } from '../payeeservice.service';
import { AnyObject } from '../view/AnyObject';
import { Payee } from '../view/Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {


  rePayeeAcctNo!:number;
  
  anyObj:AnyObject=new AnyObject();

  accNum=101;
  message!:String;
  //payeeList!:Payee[];

  constructor(private pservice:PayeeserviceService) { }

  ngOnInit(): void {
  }


  
  addPayee()
{
  this.anyObj.accNum = this.accNum;

  this.pservice.addSinglePayeesService(this.anyObj).subscribe(
    {
      
    next:(data:string) => {
      console.log('~~'+this.anyObj.payeeObj.payeeName);
      this.message = data;
      console.log(data);
      //this.payeeList.push(this.any.payee);
    
    },
    error:(err) => {
      console.log('~~~'+this.anyObj.payeeObj.payeeName);
    
      this.message=err.error;
      console.log(err);
    }
}
    );
   

}
}
