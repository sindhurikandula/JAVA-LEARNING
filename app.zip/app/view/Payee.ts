export class Payee {
    
    payeeId!: number;
    payeeAcctNo!: number;
    payeeName!: string;
    payeeNickName!:string;
    payeeLimit!: number;
    
}