import { Payee } from "./Payee";

export class AnyObject
{
    accNum!:Number;
    payeeObj:Payee=new Payee();


}