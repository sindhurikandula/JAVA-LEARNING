import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PayeeserviceService } from '../payeeservice.service';
import { Payee } from './Payee';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  allpayees: Payee[] = [
  ];
  message!: string;
  acNo: number = 101;

  constructor(private router:Router,private payeeService: PayeeserviceService ) { }

  ngOnInit(): void {
    this.payeeService.loadPayeeOfSingleAccountService(this.acNo).subscribe(
      (data) => {
        console.log('ngOnInit() loading the Payees...');
        this.allpayees = data;
      },
      (err) => {
        console.log(err);
      }
    );
  }
}