import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { Login1Component } from './login1/login1.component';
import { OurCompanyComponent } from './our-company/our-company.component';
import { OurEmployeesComponent } from './our-employees/our-employees.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PayeeComponent } from './payee/payee.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [

  {path:'about',
    children:[
      {path:'',component:AboutComponent}, 
      {path:'our-emps',component:OurEmployeesComponent},
      {path:'our-comp',component:OurCompanyComponent},

    ]
 },

{path:'Home',component:HomeComponent},
{path:'login',component:Login1Component},
{path:'register',component:RegisterComponent},
{path:'PayeeManagement',component:PayeeComponent},
{path:'MyDashboard',component:DashboardComponent},
{path:'AdminDashboard',component:AdminDashboardComponent},
{path:'**',component:PageNotFoundComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
