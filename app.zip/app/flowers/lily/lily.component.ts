import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lily',
  templateUrl: './lily.component.html',
  styleUrls: ['./lily.component.css']
})
export class LilyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
