import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoseComponent } from './rose/rose.component';
import { LilyComponent } from './lily/lily.component';
import { LotusComponent } from './lotus/lotus.component';



@NgModule({
  declarations: [
    RoseComponent,
    LilyComponent,
    LotusComponent
  ],
  imports: [
    CommonModule
  ],
 exports:[

    LilyComponent,
    RoseComponent,
    LotusComponent

  ]
})
export class FlowersModule { }
