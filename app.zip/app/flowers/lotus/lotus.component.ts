import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lotus',
  templateUrl: './lotus.component.html',
  styleUrls: ['./lotus.component.css']
})
export class LotusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
