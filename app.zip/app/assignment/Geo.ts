export class Geo
{
  lat!:string;
  lng!:string;

}