import { Component, OnInit } from '@angular/core';
import { photos } from '../assignment1/Photos';
import { PhotoService } from '../photo.service';

@Component({
  selector: 'app-assignment2',
  templateUrl: './assignment2.component.html',
  styleUrls: ['./assignment2.component.css']
})
export class Assignment2Component implements OnInit {

  anyNumber!:number;
  photo:photos=new photos();
  
  constructor(private p:PhotoService) { }

  ngOnInit(): void {
  }

  loadSinglePhotoDetails(x:number)
  {
    this.p.loadPhotoDetailsServiceById(x).subscribe(
      (data)=>
      {
      this.photo=data;
     },
      (err)=>
      {
        console.log(err);
      }

    )
  }

}




  
  


