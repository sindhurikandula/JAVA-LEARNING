import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';


@Component({
  selector: 'app-currency-converter',
  templateUrl: './currency-converter.component.html',
  styleUrls: ['./currency-converter.component.css']
})
export class CurrencyConverterComponent implements OnInit {


  convertedAmt:number=0;
  sourceCountry!:string;
  targetCountry!:string;
  amtToConvert!:number;

  constructor(private ccs:CurrencyConverterService) { }

  ngOnInit(): void {}

  convertIt()
  {
    if(this.sourceCountry == this.targetCountry) {
      alert('source and target country cannot be the same');
    }
    else if(this.amtToConvert==0 || this.amtToConvert<0 || this.amtToConvert==undefined) {
      alert('Please fill valid amount');
    }
    else {
      this.convertedAmt = this.ccs.convert(this.sourceCountry,this.targetCountry,this.amtToConvert);
    }
  }

  

}
