import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetails } from '../assignment/UserDetails';
import { User } from './User';

@Component({
  selector: 'app-login1',
  templateUrl: './login1.component.html',
  styleUrls: ['./login1.component.css']
})
export class Login1Component implements OnInit {

  userObj:User=new User();

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  authenticate()
  {
    if(this.userObj.username=="admin" && this.userObj.password=="admin123")
    {
      sessionStorage.setItem("x",JSON.stringify(this.userObj));                
      this.router.navigate(['/AdminDashboard']);         
    }
    else{

      sessionStorage.setItem("x",JSON.stringify(this.userObj));  
      this.router.navigate(['/MyDashboard']); 
    }
  }

}
