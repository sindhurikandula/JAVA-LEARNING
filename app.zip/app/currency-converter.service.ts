import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {

  constructor() { }

  convertedAmount:number=0;
  
  convert(source:string,target:string,amtToConvert:number):number
  {
      if(source=='INR'&& target=='USD')
      {
        this.convertedAmount = amtToConvert * 0.013;
      }
      else if(source=='USD'&& target=='INR')
      {
        this.convertedAmount = amtToConvert * 78;
      }

      return this.convertedAmount;
  }
}
