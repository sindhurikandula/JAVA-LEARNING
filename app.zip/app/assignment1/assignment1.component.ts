import { Component, OnInit } from '@angular/core';
import { PhotoService } from '../photo.service';
import { photos } from './Photos';

@Component({
  selector: 'app-assignment1',
  templateUrl: './assignment1.component.html',
  styleUrls: ['./assignment1.component.css']
})
export class Assignment1Component implements OnInit {

  photoList:photos[]=[];

  constructor(private p:PhotoService) { }

  ngOnInit(): void {

    this.p.loadAllPhotosService().subscribe(
      (data)=>
      {
        this.photoList=data;
        console.log(this.photoList);
      },
      (err)=> {
        console.log(err);
      }
    )
  }

}


