import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Department } from './department/Department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentServiceService {

  constructor(private myHttp:HttpClient
    ) { }

  loadAllDepartmentsService():Observable<Department[]>
   {
     return this.myHttp.get<Department[]>("http://localhost:8080/depts/");
   }

   loadSingleDepartmentService(x:number) : Observable<Department> { 
    
    return this.myHttp.get<Department>("http://localhost:8080/depts/"+x);
  }
   
   loadAddDepartmentsService(dept:Department,):Observable<string>
   {
     return this.myHttp.post<string>("http://localhost:8080/depts/addDept/",dept,{responseType:'text' as 'json'});
   }
   loadUpdateDepartmentsService(dept:Department):Observable<string>
   {
     return this.myHttp.put<string>("http://localhost:8080/depts/updateDept/",dept,{responseType:'text' as 'json'});
   }
   loadDeleteDepartmentsService(x:number):Observable<string>
   {
     return this.myHttp.delete<string>("http://localhost:8080/depts/deleteDept/"+x,{responseType:'text' as 'json'});
   }

}
