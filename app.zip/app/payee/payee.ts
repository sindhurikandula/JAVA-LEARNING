export class Payee{



    

}