import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payee',
  templateUrl: './payee.component.html',
  styleUrls: ['./payee.component.css']
})
export class PayeeComponent implements OnInit {

  payeeobj:Payee=new Payee();

 payeeAry: Payee[] = [
  {"payeeName":"Kesavardhan","payeeActNo":65432198700,"payeeActNoAgain":65432198700,"payeeLimit":50000,"payeeNickname":"Vardhan"},
  {"payeeName":"MaheswaraRessy","payeeActNo":65432198702,"payeeActNoAgain":65432198702,"payeeLimit":100000,"payeeNickname":"Dad"}
];

addPayeeToArray()
{
   this.payeeAry.push(this.payeeobj);
   alert("payee added")
}

deletePayeeFromArray(obj:Payee)
{
  this.payeeAry =  this.payeeAry.filter(item => item!= obj);

}

  constructor() { }

  ngOnInit(): void {
    
  }
}
class Payee{
  payeeName!:string;
  payeeActNo!:number;
  payeeActNoAgain!:number;
  payeeLimit!:number;
  payeeNickname!:string;
}