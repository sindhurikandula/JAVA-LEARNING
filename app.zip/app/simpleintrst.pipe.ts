import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'simpleintrst'
})
export class SimpleintrstPipe implements PipeTransform {

  transform(principal:number,years:number,rate:number):number {
    return (principal*years*rate/100);
  }

}
