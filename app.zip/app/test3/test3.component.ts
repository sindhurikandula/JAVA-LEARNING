// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

// @Component({
//   selector: 'app-test3',
//   templateUrl: './test3.component.html',
//   styleUrls: ['./test3.component.css']
// })
// export class Test3Component implements OnInit {

//   requiredForm!:FormGroup;

//   constructor(private fb:FormBuilder) { 
    
//     this.myForm();

//   }
// myForm()
// {
//   this.requiredForm=this.fb.group({

//     uname:['',Validators.required],
//     upass:['',Validators.required],
//     uage:['',Validators.required],
//     uaddress:['',Validators.required],


//   })
// }


//   ngOnInit(): void {

//     this.dataGroup=new FormGroup({
      
//       a:new FormControl(""),
            
//       b:new FormControl(""),
            
//       c:new FormControl(""),
            
//       d:new FormControl(""),


//     });

// //   }

//   onClickSubmit(result:any){
    
//     this.userName=result.a;
//     this.password=result.b;
//     this.userAge=result.c;
//     this.userAddress=result.d;

// }
// }
