import { Component, OnInit } from '@angular/core';
import { User } from '../login1/User';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  userObj:User=new User();
  anyObject:any;

  ngOnInit(): void {

    this.anyObject=sessionStorage.getItem("x");
    this.userObj=JSON.parse(this.anyObject);
  }

}
