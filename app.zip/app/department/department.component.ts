import { Component, OnInit } from '@angular/core';
import { DepartmentServiceService } from '../department-service.service';
import { Department } from './Department';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  dept:Department=new Department();
  allDepts:Department[]=[];

  constructor(private deptService:DepartmentServiceService) { }

  ngOnInit(): void {

    this.viewAll();

    }


    viewAll()
    {
      this.deptService.loadAllDepartmentsService().subscribe(
        (data)=>
        { 
           this.allDepts=data;
  
        },
        (err)=>
        {
          console.log(err);
        }
     );
  
    }

message!:string;

addDept()
{
  this.deptService.loadAddDepartmentsService(this.dept).subscribe(
    {
    next:(data:string) => {
      
      this.message = data;
      this.allDepts.push(this.dept);
    },
    error:(err) => {
      
    
      this.message=err.error;
      
    }
}
    );
    this.viewAll();
}
updateDept(deptObj:Department)
{
    this.deptService.loadUpdateDepartmentsService(deptObj).subscribe(

      {
        next:(data:string) => {
          
          this.message = data;
        },
        error:(err) => {
        
          this.message=err.error;
          
        }
    }
 );
 this.viewAll();
}

deleteDept(x:number)
{
  this.deptService.loadDeleteDepartmentsService(x).subscribe(

    {
      next:(data:string) => {
        
        this.message = data;
      },
      error:(err) => {
      
        this.message=err.error;
        
      }
  }
  );
  this.viewAll();
}

}

