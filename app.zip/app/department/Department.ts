export class Department
{
    deptNumber!:number;
    deptName!:string;
    deptLocation!:string;
}