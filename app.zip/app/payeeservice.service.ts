import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MyResponse } from './MyResponse';
import { AnyObject } from './view/AnyObject';
import { Payee } from './view/Payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeserviceService {

  constructor(private myHttp:HttpClient
    ) { }

    loadPayeeOfSingleAccountService(acNo:number) : Observable<Payee[]> { 
      console.log('loadSinglePayeesService() invoked.....');
      return this.myHttp.get<Payee[]>("http://localhost:8080/payee/"+acNo);
    }
    // addSinglePayeesService(accNo:number,payee:Payee) : Observable<string> { 
    //   console.log('addSinglePayeesService() invoked.....');
    //   return this.myHttp.post<string>("http://localhost:8080/payee/addPayee/",+accNo+"/"+payee,{ responseType: 'text' as 'json'});
    // }

    addSinglePayeesService(anyObj:AnyObject) : Observable<string> { 
      console.log('addSinglePayeesService() invoked.....');
       return this.myHttp.post<string>("http://localhost:8080/payee/addPayee/",anyObj,{ responseType: 'text' as 'json'});
     }
    updateSinglePayeesService(accNo:number, payeeId: number,payeeLimit : number ) : Observable<MyResponse> { 
      
      
      //return this.myHttp.put<string>("http://localhost:8080/payee/updatePayee/101/68/88888",{ responseType: 'text' as 'json'});
      return this.myHttp.put<MyResponse>("http://localhost:8080/payee/updatePayee/"+accNo+"/"+payeeId+"/"+payeeLimit,{ responseType: 'text' as 'json'});
    }
  
    deleteSinglePayeeByAccountNoService(acNo:number, payeeId: number) : Observable<string> { 
      console.log('deleteSinglePayeeService() invoked.....');
      return this.myHttp.delete<string>("http://localhost:8080/payee/deletePayee/"+acNo+"/"+payeeId,{ responseType: 'text' as 'json'});
}
}