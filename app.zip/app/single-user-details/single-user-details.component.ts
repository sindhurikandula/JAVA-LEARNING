import { Component, OnInit } from '@angular/core';
import { UserDetails } from '../assignment/UserDetails';
import { UserdetailsService } from '../userdetails.service';


@Component({
  selector: 'app-single-user-details',
  templateUrl: './single-user-details.component.html',
  styleUrls: ['./single-user-details.component.css']
})
export class SingleUserDetailsComponent implements OnInit {
   
  anyNumber!:number;
  userDetails:UserDetails=new UserDetails();

  constructor(private uds: UserdetailsService) { }

  ngOnInit(): void {
  }

  loadSingleUserDetails(x:number)
  {
    this.uds.loadUserDetailsServiceById(x).subscribe(
      (data)=>
      {
      this.userDetails=data;
     },
      (err)=>
      {
        console.log(err);
      }

    )
  }

}
