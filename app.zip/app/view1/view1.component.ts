import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyResponse } from '../MyResponse';
import { PayeeserviceService } from '../payeeservice.service';
import { Payee } from '../view/Payee';

@Component({
  selector: 'app-view1',
  templateUrl: './view1.component.html',
  styleUrls: ['./view1.component.css']
})
export class View1Component implements OnInit {

  allpayees: Payee[] = [ ];
  message!: string;
  acNo: number = 101;
  //payObj:Payee=new Payee();


  constructor(private router:Router,private payeeService:PayeeserviceService ) { }

  ngOnInit(): void {
    this.payeeService.loadPayeeOfSingleAccountService(this.acNo).subscribe(
      (data) => {
        console.log('ngOnInit() loading the Payees...');
        this.allpayees = data;
      },
      (err) => {
        console.log(err);
      }
    );
  }

deletePayee(pid:number)
{
  this.payeeService.deleteSinglePayeeByAccountNoService(this.acNo,pid).subscribe(
    {
        next:(data:string) => {
          this.message = data;
        },
        error:(err) => {
          this.message=err.error;
        }
    }

  );
}

updatePayee(pid:number,plimit:number)
{
  this.payeeService.updateSinglePayeesService(this.acNo,pid,plimit).subscribe(
    {
       next:(data:MyResponse) => {
        console.log('~');
        this.message = data.message;
        console.log(data);
        console.log(this.message);
      },
      error:(err) => {
        console.log('~~');
        this.message =err.error;
        console.log(err);
        //alert(err);
        //this.message=err.error;
      },
      complete:() => {
        console.log('~~~');
      }
    }

  );
}


}

