import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PayeeComponent } from './payee/payee.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { SimpleInterestCalculatorComponent } from './simple-interest-calculator/simple-interest-calculator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BankApplicantComponent } from './bank-applicant/bank-applicant.component';
import { AssignmentComponent } from './assignment/assignment.component';
import { SquarePipe } from './square.pipe';
import { SquarerootPipe } from './squareroot.pipe';
import { SimpleintrstPipe } from './simpleintrst.pipe';
import { BalancePipe } from './balance.pipe';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';
import {HttpClientModule} from '@angular/common/http';
import { SingleUserDetailsComponent } from './single-user-details/single-user-details.component'
import { Assignment1Component } from './assignment1/assignment1.component';
import { Assignment2Component } from './assignment2/assignment2.component';
import { DepartmentComponent } from './department/department.component';
import { AboutComponent } from './about/about.component';
import { OurEmployeesComponent } from './our-employees/our-employees.component';
import { OurCompanyComponent } from './our-company/our-company.component';
import { Login1Component } from './login1/login1.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { LogoutComponent } from './logout/logout.component';
import { TestComponent } from './test/test.component';
import { ViewComponent } from './view/view.component';
import { View1Component } from './view1/view1.component';
import { AddPayeeComponent } from './add-payee/add-payee.component';


@NgModule({
  declarations: [
    AppComponent,
    PayeeComponent,
    RegistrationComponent,
    LoginComponent,
    SimpleInterestCalculatorComponent,
    BankApplicantComponent,
    AssignmentComponent,
    SquarePipe,
    SquarerootPipe,
    SimpleintrstPipe,
    BalancePipe,
    CurrencyConverterComponent,
    SingleUserDetailsComponent,
    Assignment1Component,
    Assignment2Component,
    DepartmentComponent,
    AboutComponent,
    OurEmployeesComponent,
    OurCompanyComponent,
    Login1Component,
    RegisterComponent,
    DashboardComponent,
    PageNotFoundComponent,
    AdminDashboardComponent,
    LogoutComponent,
    TestComponent,
    ViewComponent,
    View1Component,
    AddPayeeComponent

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
