import { SimpleintrstPipe } from './simpleintrst.pipe';

describe('SimpleintrstPipe', () => {
  it('create an instance', () => {
    const pipe = new SimpleintrstPipe();
    expect(pipe).toBeTruthy();
  });
});
