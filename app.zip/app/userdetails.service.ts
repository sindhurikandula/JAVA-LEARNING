import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserDetails } from './assignment/UserDetails';




@Injectable({
  providedIn: 'root'
})
export class UserdetailsService {

  constructor(private myHttp:HttpClient) { }

   loadAllUserDetailsService():Observable<UserDetails[]>
   {
     return this.myHttp.get<UserDetails[]>("https://jsonplaceholder.typicode.com/users");
   }

   loadUserDetailsServiceById(x:number):Observable<UserDetails>
   {
     return this.myHttp.get<UserDetails>("https://jsonplaceholder.typicode.com/users/"+x);
   }


  }
