import { Component, OnInit } from '@angular/core';
import { User } from '../login1/User';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  userObj:User=new User();
  anyObject:any;

  constructor() { }

  ngOnInit(): void {

    this.anyObject=sessionStorage.getItem("x");
    this.userObj=JSON.parse(this.anyObject);
  }

}
