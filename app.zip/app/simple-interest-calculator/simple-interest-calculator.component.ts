import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-interest-calculator',
  templateUrl: './simple-interest-calculator.component.html',
  styleUrls: ['./simple-interest-calculator.component.css']
})
export class SimpleInterestCalculatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  principal!:number; //DATA MEMBER
  noOfyears!:number; //DATA MEMBER
  rateOfIntrst!:number; //DATA MEMBER
  simpleInterest:number=0; //DATA MEMBER


  calculateSimpleInterest() // MEMBER function
  {   
    this.simpleInterest=(this.principal*this.noOfyears*this.rateOfIntrst)/100;   
  }


}
