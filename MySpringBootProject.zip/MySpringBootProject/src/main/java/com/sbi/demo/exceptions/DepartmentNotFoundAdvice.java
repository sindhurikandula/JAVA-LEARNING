package com.sbi.demo.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class DepartmentNotFoundAdvice {
	
	@ResponseBody
	@ExceptionHandler(DepartmentNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	String departmentNotFoundHandler(DepartmentNotFoundException e)
	{
		System.out.println("departmentNotFoundHandler");
		return e.getMessage()+ " its not there, means 404";
	}

}

