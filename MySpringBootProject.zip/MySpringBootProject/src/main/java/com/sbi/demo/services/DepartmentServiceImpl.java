package com.sbi.demo.services;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.*;
import com.sbi.demo.repositories.DepartmentRepository;


@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository depReps;
	
	@Override
	public List<Department>fetchAllDepartmentsService() {
		
		
		List<Department> deptList=depReps.findAllDepartments();
		return deptList;
          
	}

	@Override
	public Department fetchDepartmentByIdService(int id)throws DepartmentNotFoundException 
	{
		Department dept=null;
		try {
			 dept=depReps.findDepartmentById(id);
		} 
		catch (DepartmentNotFoundException e) {
			
			throw e;
		}
		
		return dept;
		
	}

	@Override
	public void insertDepartmentByService(Department d)throws DepartmentAlreadyExistsException  {
	    try { 
	    	
		depReps.insertDepartment(d);
		}
	    catch(DepartmentAlreadyExistsException e)
	    {
	    	throw e;
	    }
	}

	@Override
	public void updateDepartmentByService(Department d)throws DepartmentNotFoundException  {
	
		try {
		depReps.updateDepartment(d);
		}
        catch (DepartmentNotFoundException e) {
			
			throw e;
		}
		
		
	}

	@Override
	public void deleteDepartmentByIdService(int id)throws DepartmentNotFoundException  {
	
		try {
		depReps.deleteDepartment(id);
		}
        catch (DepartmentNotFoundException e) {
			
			throw e;
		}
		
		
	}

	

}