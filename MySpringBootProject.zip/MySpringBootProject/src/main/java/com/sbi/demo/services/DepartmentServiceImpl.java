package com.sbi.demo.services;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.repositories.DepartmentRepository;


@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository depReps;
	
	@Override
	public List<Department>fetchAllDepartmentsService() {
		
		
		List<Department> deptList=depReps.findAllDepartments();
		return deptList;
          
	}

	@Override
	public Department fetchDepartmentByIdService(int id) {
		
		return depReps.findDepartmentById(id);
	}

	@Override
	public void insertDepartmentByService(Department d) {
	
		depReps.insertDepartment(d);
	}

	@Override
	public void updateDepartmentByService(Department d) {
	
		depReps.updateDepartment(d);
	}

	@Override
	public void deleteDepartmentByIdService(int id) {
	
		depReps.deleteDepartment(id);
		
	}

	

}