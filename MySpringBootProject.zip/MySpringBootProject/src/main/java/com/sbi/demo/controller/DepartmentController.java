package com.sbi.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;
import com.sbi.demo.services.DepartmentService;

@CrossOrigin
@RestController
@RequestMapping("/depts")
public class DepartmentController {
	
	/*@RequestMapping("/Welcome")
	public String greet()
	{
		return"<h1>Welcome to Department Controller</h1>";//http://localhost:8080/depts/Welcome
	}*/
	
	
	@Autowired
	DepartmentService deptService;
	
	
	@RequestMapping("/")
	public List<Department> allDepts()
	{
		return deptService.fetchAllDepartmentsService();
	}
	
	@RequestMapping("/{dno}")
	public Department getSingleDept(@PathVariable("dno") int x)throws DepartmentNotFoundException 
	{
		Department dept=null;
		try {
			 dept= deptService.fetchDepartmentByIdService(x);
		} 
		catch (DepartmentNotFoundException e) {
			
			throw e;
		}
		
		return dept;
	}
	
	@PostMapping("/addDept")
	public String insertDepartment(@RequestBody Department dept) throws DepartmentAlreadyExistsException
	{
		try {
		deptService.insertDepartmentByService(dept);
		}
		catch(DepartmentAlreadyExistsException e)
		{
			throw e;
			
		}
		
		return "Department added successfully";
	}
	
	@PutMapping("/updateDept")
	public String updateDepartment(@RequestBody Department dept) throws DepartmentNotFoundException
	{
		try {
		deptService.updateDepartmentByService(dept);
		}
         catch (DepartmentNotFoundException e) {
			
			throw e;
		}
		
		return "Department updated successfully";
		
	}
	
	@DeleteMapping("/deleteDept/{x}")
	public String deleteDepartmentt(@PathVariable("x") int deptnoTobeDelted) throws DepartmentNotFoundException
	{
		try {
		deptService.deleteDepartmentByIdService(deptnoTobeDelted);
		}
        catch (DepartmentNotFoundException e) {
			
			throw e;
		}
		
		return "Department deleted  successfully";
		
	}

}

