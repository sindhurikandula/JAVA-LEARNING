package com.sbi.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import com.sbi.demo.entity.Department;
import com.sbi.demo.services.DepartmentService;

@RestController
@RequestMapping("/depts")
public class DepartmentController {
	
	/*@RequestMapping("/Welcome")
	public String greet()
	{
		return"<h1>Welcome to Department Controller</h1>";//http://localhost:8080/depts/Welcome
	}*/
	
	
	@Autowired
	DepartmentService deptService;
	
	
	@RequestMapping("/")
	public List<Department> allDepts()
	{
		return deptService.fetchAllDepartmentsService();
	}
	
	@RequestMapping("/{dno}")
	public Department getSingleDept(@PathVariable("dno") int x)
	{
		return deptService.fetchDepartmentByIdService(x);
	}
	
	@PostMapping("/addDept")
	public void insertDepartment(@RequestBody Department dept)
	{
		deptService.insertDepartmentByService(dept);
	}
	
	@PutMapping("/updateDept")
	public void updateDepartment(@RequestBody Department dept)
	{
		deptService.updateDepartmentByService(dept);
	}
	
	@DeleteMapping("/deleteDept/{x}")
	public void deleteDepartmentt(@PathVariable("x") int deptnoTobeDelted)
	{
		deptService.deleteDepartmentByIdService(deptnoTobeDelted);
	}

}

