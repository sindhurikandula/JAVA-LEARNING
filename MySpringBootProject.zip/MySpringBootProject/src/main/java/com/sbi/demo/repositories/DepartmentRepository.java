package com.sbi.demo.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.*;


@Repository
public interface DepartmentRepository {
	
	 List<Department> findAllDepartments();
	 Department findDepartmentById(int id)throws DepartmentNotFoundException;
	 void insertDepartment(Department d) throws DepartmentAlreadyExistsException;
	 void updateDepartment(Department d)throws DepartmentNotFoundException;
	 void deleteDepartment(int id)throws DepartmentNotFoundException;
	 

}