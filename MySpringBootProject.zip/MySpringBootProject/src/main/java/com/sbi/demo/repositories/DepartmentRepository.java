package com.sbi.demo.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Department;


@Repository
public interface DepartmentRepository {
	
	 List<Department> findAllDepartments();
	 Department findDepartmentById(int id);
	 void insertDepartment(Department d);
	 void updateDepartment(Department d);
	 void deleteDepartment(int id);
	 

}