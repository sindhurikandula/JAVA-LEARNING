package com.sbi.demo.repositories;

import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.*;

@Repository("rep")
public class DepartmentRepositoryImpl implements DepartmentRepository {
	
	//EntityManagerFactory emf;
	
	@PersistenceContext
	EntityManager em;
	
	
	public DepartmentRepositoryImpl()
	{
		//emf=Persistence.createEntityManagerFactory("MyJPA");
		//System.out.println("EMF created:"+emf);
		
		//em=emf.createEntityManager();
		System.out.println("EM created:"+em);
		
	}


	@Override
	public List<Department> findAllDepartments() {
		
		TypedQuery<Department> q=em.createQuery("from Department",Department.class);
		return q.getResultList();
     }


	@Override
	public Department findDepartmentById(int id)throws DepartmentNotFoundException
	{
		
		Department dept= em.find(Department.class,id);
		if(dept==null)
		{
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
		return dept;
		
	}


	@Override
	@Transactional
	public void insertDepartment(Department d)throws DepartmentAlreadyExistsException  
	{
	    Department deptTemp=em.find(Department.class, d.getDeptNumber());	
	    if(deptTemp!=null)
	    {
	    	throw new DepartmentAlreadyExistsException("This Department number "+d.getDeptNumber()+ " already exists");
	    }
		em.persist(d);
		
	}


	@Override
	@Transactional
	public void updateDepartment(Department d)throws DepartmentNotFoundException {
		
		Department deptTemp=em.find(Department.class, d.getDeptNumber());
		if(deptTemp==null)
		{
			throw new DepartmentNotFoundException("Department NOT found : "+d.getDeptNumber());
		}
		em.merge(d);
	}


	@Override
	@Transactional
	public void deleteDepartment(int id)throws DepartmentNotFoundException {
		
		Department d=em.find(Department.class,id);
		if(d==null)
		{
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
	
		em.remove(d);
	}


	
	
}	
