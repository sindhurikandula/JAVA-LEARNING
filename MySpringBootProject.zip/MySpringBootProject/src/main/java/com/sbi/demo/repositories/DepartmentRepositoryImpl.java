package com.sbi.demo.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.demo.entity.Department;


@Repository("rep")
public class DepartmentRepositoryImpl implements DepartmentRepository {
	
	//EntityManagerFactory emf;
	
	@PersistenceContext
	EntityManager em;
	
	
	public DepartmentRepositoryImpl()
	{
		//emf=Persistence.createEntityManagerFactory("MyJPA");
		//System.out.println("EMF created:"+emf);
		
		//em=emf.createEntityManager();
		System.out.println("EM created:"+em);
		
	}


	@Override
	public List<Department> findAllDepartments() {
		
		TypedQuery<Department> q=em.createQuery("from Department",Department.class);
		return q.getResultList();
     }


	@Override
	public Department findDepartmentById(int id) {
		
		return em.find(Department.class,id);
		
	}


	@Override
	@Transactional
	public void insertDepartment(Department d) {
		
		em.persist(d);
		
		}


	@Override
	@Transactional
	public void updateDepartment(Department d) {
		
		em.merge(d);
	}


	@Override
	@Transactional
	public void deleteDepartment(int id) {
		
		Department d=em.find(Department.class,id);
		em.remove(d);
	}


	
	
}	
