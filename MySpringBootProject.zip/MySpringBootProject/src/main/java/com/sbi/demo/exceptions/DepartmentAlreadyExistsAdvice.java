package com.sbi.demo.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class DepartmentAlreadyExistsAdvice {
	
	@ResponseBody
	@ExceptionHandler(DepartmentAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.FOUND)
	String deptAlreadyExistsExceptionHandler(DepartmentAlreadyExistsException e)
	{
	    return e.getMessage();
	}

}
