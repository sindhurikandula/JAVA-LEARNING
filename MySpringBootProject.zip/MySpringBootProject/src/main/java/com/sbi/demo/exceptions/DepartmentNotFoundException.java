package com.sbi.demo.exceptions;

public class DepartmentNotFoundException extends Exception {

	public DepartmentNotFoundException(String message) {
		super(message);
		
	}
}
