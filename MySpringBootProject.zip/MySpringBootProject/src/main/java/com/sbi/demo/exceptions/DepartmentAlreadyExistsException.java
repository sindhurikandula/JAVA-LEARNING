package com.sbi.demo.exceptions;

public class DepartmentAlreadyExistsException extends Exception {

	public DepartmentAlreadyExistsException(String message) {
		super(message);
	}

}
