package com.sbi.demo.services;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.*;

import java.util.*;

@Service
public interface DepartmentService {

	List<Department> fetchAllDepartmentsService();
	Department fetchDepartmentByIdService(int id) throws DepartmentNotFoundException;
	void insertDepartmentByService(Department d)throws DepartmentAlreadyExistsException;
	void updateDepartmentByService(Department d)throws DepartmentNotFoundException;
	void deleteDepartmentByIdService(int id)throws DepartmentNotFoundException;
	
}
