package com.sbi.demo.services;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;

import java.util.*;

@Service
public interface DepartmentService {

	List<Department> fetchAllDepartmentsService();
	Department fetchDepartmentByIdService(int id);
	void insertDepartmentByService(Department d);
	void updateDepartmentByService(Department d);
	void deleteDepartmentByIdService(int id);
	
}
