package com.sbi.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
