package dao.bankapplicant;

import java.util.List;

public interface BankApplicantDAO {

	void saveBankApplicant(BankApplicant ba);//C
	BankApplicant findBankApplicant(int aid);//R
	List<BankApplicant> findAllBankApplicants();//read all
	void updateBankApplicant(BankApplicant ba);//U
	void deleteBankApplicant(int aid);//D
	
}
