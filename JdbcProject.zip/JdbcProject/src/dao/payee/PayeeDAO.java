package dao.payee;

import java.util.List;

public interface PayeeDAO {

	  Payee findPayeeByAccountNumber(int accno);
	  List<Payee> findAllPayees();
	  void savePayee(Payee p);
	  void updatePayee(Payee p);
	  void deletePayeeByAccountNumber(int accno);
}
;