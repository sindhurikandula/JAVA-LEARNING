package dao.bankaccount;

import java.util.List;

public interface BankAccountDAO {
		
		BankAccount findBankAccountById(int acctno);
		List<BankAccount> findAllBankAccounts();
		void saveBankAccount(BankAccount obj);
		void updateBankAccount(BankAccount obj);
		void deleteBankAccountById(int acctno);

	}

 