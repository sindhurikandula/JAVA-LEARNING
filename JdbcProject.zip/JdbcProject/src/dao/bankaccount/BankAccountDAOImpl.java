package dao.bankaccount;

import java.sql.*;
import java.util.List;

public class BankAccountDAOImpl implements BankAccountDAO {
	
	Connection conn;
	BankAccountDAOImpl(){
		
		System.out.println("BankAccountDAOImpl() constructor is invoked");
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver Loaded");
			
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "sysgitc");
			System.out.println("Connected to DB"+conn);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public BankAccount findBankAccountById(int acctno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BankAccount> findAllBankAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveBankAccount(BankAccount obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBankAccount(BankAccount obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBankAccountById(int acctno) {
		// TODO Auto-generated method stub
		
	}

}
