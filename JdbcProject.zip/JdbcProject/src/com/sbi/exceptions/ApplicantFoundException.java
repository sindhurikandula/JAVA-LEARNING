package com.sbi.exceptions;

public class ApplicantFoundException extends Exception {

	public ApplicantFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
  
}
