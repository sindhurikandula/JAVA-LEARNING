package com.sbi.exceptions;

public class ApplicantNotFoundException extends Exception
{

	public ApplicantNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
