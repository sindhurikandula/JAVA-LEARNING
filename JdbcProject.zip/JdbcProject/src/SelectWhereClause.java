import java.sql.*;
import java.util.Scanner;

import com.sbi.exceptions.ApplicantNotFoundException;

public class SelectWhereClause {
	
	public static void main(String[] args) {

		try {
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registered successfully....");

			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected to DB...");

			Statement st = conn.createStatement();
			System.out.println("statement is created");
			
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter Applicant ID:");
			int appid=scan.nextInt();
			

		    ResultSet rs = st.executeQuery("SELECT * FROM BANK_APPLICANT WHERE APPLICANT_ID="+appid);
			System.out.println("Query fired ..got the results");

			if(rs.next()) {
				System.out.println("APPLICANT_ID :" + rs.getInt(1));
				System.out.println("APPLICANT NAME   : " + rs.getString(2));
				System.out.println("APPLICANT EMAIL  : " + rs.getString(3));
				System.out.println("APPLICANT Mobile : " + rs.getString(4));
				System.out.println("APPLICANT DOB    : " + rs.getDate(5));
				System.out.println("APPLICANT ADDRESS: " + rs.getString(6));
				System.out.println("-----------------------------");
			}
			else
			{
				throw new ApplicantNotFoundException("The applicant with this id is not found : "+appid);
			}

			rs.close();
			st.close();
			conn.close();
			System.out.println("DisConnected from the db....");

		}

		catch (SQLException e) {

			e.printStackTrace();
		}
	   catch(ApplicantNotFoundException e) {
		   e.printStackTrace();
	}
}
}
