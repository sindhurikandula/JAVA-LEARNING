import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.Department;


public class DeptTest {

	public static void main(String[] args) {
		System.out.println("trying to load the application context...");
		ApplicationContext container = new ClassPathXmlApplicationContext("myspring3.xml");
		System.out.println("application context...loaded.....");
		System.out.println("-------------------");
     
		Department dept = (Department) container.getBean("dept"); 
		dept.showAllDepartments();
		
	}

}
