import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.*;

public class CarTest
{
   public static void main(String[] args)
   {
	 ApplicationContext container=new ClassPathXmlApplicationContext("myspring.xml");
	 System.out.println("Application context loaded");
	 System.out.println("-----------------");
	 
	 Car carObj=(Car) container.getBean("x");
	 carObj.startCar();
	 System.out.println("carObj: "+carObj);
	 
	 System.out.println("-----------------");
	 
	 Car carObj1=(Car) container.getBean("x");
	 carObj1.startCar();
	 System.out.println("carObj1: "+carObj1);
   }
}
