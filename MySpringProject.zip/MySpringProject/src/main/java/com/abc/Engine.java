package com.abc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component//("eng")
public class Engine {

	@Autowired
	Piston pistObj;

/*@Autowired	
public void setPistoneering(Piston x) 
{
 System.out.println("setEngine(Piston) is called");
		pistObj = x;
}*/

public void igniteEngine() {
		pistObj.firePiston();
		System.out.println("Engine is ignited");
	}
}


