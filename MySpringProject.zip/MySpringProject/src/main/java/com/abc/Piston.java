package com.abc;

import org.springframework.stereotype.Component;

@Component
public class Piston {

	public void firePiston() {
	System.out.println("Piston is fired");
		}
}


