
package com.abc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component//("desEng")
public class DieselEngine extends Engine{

	@Autowired
	Piston pistObj;

public void igniteEngine() {
		pistObj.firePiston();
		System.out.println("DieselEngine is ignited");
	}
}

