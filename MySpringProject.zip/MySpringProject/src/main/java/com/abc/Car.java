package com.abc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("x")
public class Car {
	
	
	@Autowired
    @Qualifier("dieselEngine")
	Engine engObj;
	
    /*@Autowired
	public void setEngineering(Engine x) 
	{
		System.out.println("setEngine(Engine) is invoked");
		engObj = x;*/

	public void startCar() {
		engObj.igniteEngine();
		System.out.println("Car started");
	}
}