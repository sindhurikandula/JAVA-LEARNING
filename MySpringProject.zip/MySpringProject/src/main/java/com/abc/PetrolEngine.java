package com.abc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component//("petEng")
public class PetrolEngine extends Engine{

	@Autowired
	Piston pistObj;

public void igniteEngine() {
		pistObj.firePiston();
		System.out.println("petrolEngine is ignited");
	}
}


