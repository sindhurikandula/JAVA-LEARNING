package com.xyz;

public class Car {
	Engine engObj;

	public void setEngineering(Engine x) 
	{
		System.out.println("setEngine(Engine) is invoked");
		engObj = x;
	}

	public void startCar() {
		engObj.igniteEngine();
		System.out.println("Car started");
	}
}