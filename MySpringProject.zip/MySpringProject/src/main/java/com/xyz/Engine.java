package com.xyz;

public class Engine {

	Piston pistObj;

public void setPistoneering(Piston x) 
{
 System.out.println("setEngine(Piston) is called");
		pistObj = x;
}

public void igniteEngine() {
		pistObj.firePiston();
		System.out.println("Engine is ignited");
	}
}


