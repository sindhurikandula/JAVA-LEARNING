package com.xyz;

public class Piston {

	public void firePiston() {
	System.out.println("Piston is fired");
		}
}


