package com.sbi.dept;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class DepartmentTest {

	public static void main(String[] args) {
		
		ApplicationContext container=new ClassPathXmlApplicationContext("myspring5.xml");
		System.out.println("application context...loaded.....");
		
	   //DepartmentRepository depReps=(DepartmentRepository)container.getBean("rep");
		
		DepartmentRepository depReps=(DepartmentRepository)container.getBean("rep");
		
		List<Department> deptList=depReps.findAllDepartments();
		for(Department d:deptList)
		{
			System.out.println("DEPTNO : "+d.getDeptNumber());
			System.out.println("DNAME  : "+d.getDeptName());
			System.out.println("DLOC   : "+d.getDeptLocation());
			System.out.println("----------------------------------");
		}
		
	
	}

}
