package com.sbi.dept;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


@Repository("rep")
public class DepartmentRepositoryImpl implements DepartmentRepository {
	
	EntityManagerFactory emf;
	EntityManager em;
	
	
	public DepartmentRepositoryImpl()
	{
		emf=Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EMF created:"+emf);
		
		em=emf.createEntityManager();
		System.out.println("EM created:"+em);
		
	}


	@Override
	public List<Department> findAllDepartments() {
		
		TypedQuery<Department> q=em.createQuery("from Department",Department.class);
		return q.getResultList();
 }
}	
