package com.sbi.dept;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository depReps;
	
	@Override
	public void fetchAllDepartmentsService() {
		
		Scanner scan1=new Scanner(System.in);
		Scanner scan2=new Scanner(System.in);
		
		System.out.println("Enter username : ");
		String username = scan1.next();
		System.out.println("Enter password : ");
		String password = scan2.next();
		
		if(username.equals("admin") && password.equals("admin123")) {
	    System.out.println("Welcome admin...");
		
		List<Department> deptList=depReps.findAllDepartments();
		for(Department d:deptList)
		{
			System.out.println("DEPTNO : "+d.getDeptNumber());
			System.out.println("DNAME  : "+d.getDeptName());
			System.out.println("DLOC   : "+d.getDeptLocation());
			System.out.println("----------------------------------");
		}
		}
		else
		{
			throw new RuntimeException("Only admin can view all the departments...");
		}
          
	}

}
