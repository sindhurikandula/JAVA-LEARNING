package com.sbi.dept;

import java.util.List;

import org.springframework.stereotype.Repository;


@Repository
public interface DepartmentRepository {
	
	List<Department> findAllDepartments();

}