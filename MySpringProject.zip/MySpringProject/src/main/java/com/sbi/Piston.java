package com.sbi;

public class Piston {

	public Piston()
	{
		System.out.println("Piston constructor is invoked");
	}
	
	void firePiston()
	{
	System.out.println("Piston is fired");
	}
}


