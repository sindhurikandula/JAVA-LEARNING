package com.sbi;

public class Engine {

		Piston pistObj;

 public Engine(Piston x) {
	 System.out.println("Engine(Piston) constructor is invoked");
			pistObj = x;
		}

 public void igniteEngine() {
			pistObj.firePiston();
			System.out.println("Engine is ignited");
		}
	}

