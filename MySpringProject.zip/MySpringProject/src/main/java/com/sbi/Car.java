package com.sbi;
public class Car {
	Engine engObj;

	public Car(Engine x) {
		System.out.println("Car(Engine) constructor is invoked");
		engObj = x;
	}

	public void startCar() {
		engObj.igniteEngine();
		System.out.println("Car started");
	}
}