import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.abc.Car;



public class CarComponentTest {

	public static void main(String[] args) {
		
		ApplicationContext container=new ClassPathXmlApplicationContext("myspring4.xml");
		 System.out.println("Application context loaded");
		 System.out.println("-----------------");
		 
		 Car carObj=(Car) container.getBean("x");
		 carObj.startCar();
		 System.out.println("carObj: "+carObj);
		 
		 System.out.println("-----------------");
		
	}

}
