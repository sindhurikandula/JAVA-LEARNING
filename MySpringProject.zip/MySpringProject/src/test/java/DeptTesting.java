import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.dept.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring5.xml"})
public class DeptTesting {
	
	/*@Autowired
	DepartmentRepository depReps;
	
	@Autowired
	DepartmentRepositoryImpl depReps;*/
	
	@Autowired
	@Qualifier("rep")
	DepartmentRepository depReps;
	
	@Test
	public void loadAllDepts()
	{
		/*ApplicationContext container=new ClassPathXmlApplicationContext("");
		System.out.println("application context...loaded.....");
		
		DepartmentRepository depReps=(DepartmentRepository)container.getBean("rep");
		
		DepartmentRepositoryImpl depReps=(DepartmentRepositoryImpl)container.getBean("rep");*/
		
		List<Department> deptList=depReps.findAllDepartments();
		for(Department d:deptList)
		{
			System.out.println("DEPTNO : "+d.getDeptNumber());
			System.out.println("DNAME  : "+d.getDeptName());
			System.out.println("DLOC   : "+d.getDeptLocation());
			System.out.println("----------------------------------");
		}
		
	}

}
