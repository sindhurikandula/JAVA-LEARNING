import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.dept.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring5.xml"})
public class DeptServiceTest {
	
    @Autowired
	DepartmentService depService;
	
	
	@Test
	public void loadAllDepts()
	{
	
	  depService.fetchAllDepartmentsService();
		
	}

}
