
public class ProducesARelationshipTest {

	public static void main(String[] args) {

		Sheep s = new Sheep();
		Wool w = s.shearASheep();
		YarnThread y = w.spin();
		WoolenGarments ws = y.sewing();
		ws.sweater();

	}
}

class Animal {

}

class Sheep extends Animal {
	Wool shearASheep() {
		Wool w = new Wool();
		return w;
	}
}

class Wool {
	YarnThread spin() {
		YarnThread y = new YarnThread();
		return y;
	}
}

class YarnThread {
	WoolenGarments sewing() {
		WoolenGarments wg = new WoolenGarments();
		return wg;
	}
}

class WoolenGarments {
	void sweater() {
		System.out.println("Sweater is ready");
	}
}
