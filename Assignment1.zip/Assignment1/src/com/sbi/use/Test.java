package com.sbi.use;

import com.sbi.livingbeing.*;
import com.sbi.person.*;


public class Test {

	public static void main(String[] args) {
		
	     livingbeing1 lb1=new Tree();
	     lb1.breathIn();
	     lb1.breathOut();
         System.out.println("--------------------------");
         
         livingbeing1 lb2=new Student();
         lb2.breathIn();//method overridden
         lb2.breathOut();
         System.out.println("--------------------------");
         
         Tree t=new Tree();
         t.rootsFunctionality();
         System.out.println("--------------------------");
         
         livingbeing1 lb3=new Reptile();
         lb3.breathIn();
         lb3.breathOut();
         System.out.println("--------------------------");
         
        /* Reptile r=new Reptile();
         r.layEggs();default method can be called only in the same package
         */
        		 
         mammal m=new Student();
         m.giveBirth();
         
         System.out.println("--------------------------");
         
       /*  System.out.println("student details");
         
         Employee e=new Executive();
         e.name();
         e.age();
         e.getClassStudying();
         e.fatherName();
         System.out.println("--------------------------");*/
         
         Human h=new Manager();
         h.live();
         System.out.println("--------------------------");
         
         System.out.println("--------------------------");
         studentrecord sr=new Director();
         Manager x=new Founder();
         result r= x.writeExam(sr);//passing and returning interface
         r.marks();
         r.rank();
         System.out.println("--------------------------");
         
         Employee e=new Executive();
         e.work(sr);
         System.out.println("--------------------------");
         
         
         
         
         
	}  
	

}
