package com.sbi.person;

public interface result {
	
	void marks();
	void rank();
}
