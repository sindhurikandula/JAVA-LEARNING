package com.sbi.person;

public class Manager extends Executive {

	public void manage(Student s,Person1 p) 
	{
		p.active();
		s.name();
		 System.out.println("student is person and student became manager");
	
	}  
}
