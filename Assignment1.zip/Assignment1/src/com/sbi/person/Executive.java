package com.sbi.person;

public class Executive extends Employee {

	public void execute(Person1 p) {
		System.out.println("person is executive...");
		p.active();
	}
}
