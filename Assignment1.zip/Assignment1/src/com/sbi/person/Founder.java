package com.sbi.person;

public class Founder extends Director {

	void found() {
		System.out.println("Found a company.....");
		
	}
}
