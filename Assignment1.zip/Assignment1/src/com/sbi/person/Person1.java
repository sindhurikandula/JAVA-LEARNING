package com.sbi.person;

import com.sbi.livingbeing.Human;

public class Person1 extends Human {
	
	public void active() {
		System.out.println("Person is active......");	//explicit method
	}
	
	
}
