package com.sbi.person;

public class Employee extends Student {
	
	public void work(studentrecord s) {
		
		System.out.println("Student is studying....");
		s.name();
		s.age();
		System.out.println("Student on studying becomes Employee and employee is working......");
		
	}
}
