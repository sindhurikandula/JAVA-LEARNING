package com.sbi.person;

public interface studentrecord {

	void name();
	void age();
	void getClassStudying();
	void fatherName();
}
