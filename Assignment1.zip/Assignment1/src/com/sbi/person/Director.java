package com.sbi.person;

public class Director extends Manager {

	public void direct() {
		System.out.println("Director is directing...");
	}
}
