package com.sbi.person;

import java.util.Scanner;

public class Student extends Person1 implements studentrecord, result {

	String name;
	int age;
	int classStudying;
	String fatherName;
	
	public void study(Student s)
	{
		System.out.println("Student is studying");
	}
	

	@Override
	public void name() {
		System.out.println("Enter Name:");
		Scanner scan= new Scanner(System.in);
		name=scan.nextLine();
		System.out.println("Name of the student is..."+name);
		
	}


	@Override
	public void age() {
		System.out.println("Enter age:");
		Scanner scan= new Scanner(System.in);
		age=scan.nextInt();
		System.out.println("Age of the student is..."+age);
		
	}

	@Override
	public void getClassStudying() {
		System.out.println("Enter the class studying-");
		Scanner scan= new Scanner(System.in);
		classStudying =scan.nextInt();
		System.out.println("Student is studying"+classStudying+"th class");
		
	}

	@Override
	public void fatherName() {
		
		 System.out.println("Enter father name:");
		Scanner scan= new Scanner(System.in);
		fatherName=scan.nextLine();
		System.out.println("Father name  is..."+fatherName);
		
		
	}

	@Override
	public void marks() {
		
		System.out.println("student secured 100 marks");
	}

	@Override
	public void rank() {
		System.out.println("student secured 2nd rank");

	}
	
	public result writeExam(studentrecord st)
	{
		System.out.println("Details of student writing exam are as follows:");
		st.name();
		st.getClassStudying();

       Student s=new Student();
       return s;

	}

}
