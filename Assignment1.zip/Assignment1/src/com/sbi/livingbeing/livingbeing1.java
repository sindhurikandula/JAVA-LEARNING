package com.sbi.livingbeing;

public interface livingbeing1 {

	void breathIn();
	void breathOut();
}
