package com.sbi.livingbeing;

public interface animal extends livingbeing1 {

	void fear();
	void eat();
	void sleep();
	void reproduction();
	void hunt();
}
