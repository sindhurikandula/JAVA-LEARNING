package com.sbi.livingbeing;

class Blood{}
class PurifiedBlood{
	void fun()
	{
		System.out.println("blood is purified");
	}
}
class Heart
{
	PurifiedBlood pumping(Blood b)//object as arugment and return type
	{
		System.out.println("purifies the blood.....");
		PurifiedBlood pb=new PurifiedBlood();
		return pb;
	}
}


public class Human implements mammal//Human has to define all the methods of interfaces animal,mamal and living being
{
	Blood bl=new Blood();//hasA
	Heart h=new Heart();//hasA

	
	public void live()//object as argument
	{
	
		PurifiedBlood p=h.pumping(bl);
		p.fun();
	
	}
	


@Override
public void fear() {
	System.out.println("Human fear about future......");
	
}

@Override
public void eat() {
	System.out.println("Humans eat food....");
	
}

@Override
public void sleep() {
	System.out.println("Humans have to sleep for a minimum of 6 hours.....");
	
}

@Override
public void reproduction() {
	System.out.println("reproduction..................");
	
}

@Override
public void hunt() {
	System.out.println("Humans can also hunt....");

}

@Override
public void breathIn() {
	System.out.println("Humans inhale");
	
}

@Override
public void breathOut() {
	System.out.println("Humans exhale.....");
	
}

@Override
public void giveBirth() {
	System.out.println("Humans can give birth...");
}

protected void feel()//explicit method
{
	System.out.println("Humans can feel...");
}

protected void talk()//explicit method
{
	System.out.println("Humans can talk...");
}

}	