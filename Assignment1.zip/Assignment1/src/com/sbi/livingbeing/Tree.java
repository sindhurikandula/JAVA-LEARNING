package com.sbi.livingbeing;

public class Tree implements livingbeing1 {

	Roots rt=new Roots();//hasA
	Branches b=new Branches();//hasA
	Trunk t=new Trunk();//hasA
	
	@Override
	public void breathIn() {
	
		System.out.println("Tree is inhaling...");
		
	}
	@Override
	public void breathOut() {
	
		System.out.println("Tree is exhaling...");
	}
     
	public void rootsFunctionality()
	{
		rt.absorb();
		rt.store();
	}


}

 class Roots
{
	void absorb()
	{
		System.out.println("Roots absorb minerals ,nutrients and water from soil...");
	}
	void store()
	{
		System.out.println("Roots store the food...");
	}
}
class Branches
{
	
}
class Trunk
{
	
}
