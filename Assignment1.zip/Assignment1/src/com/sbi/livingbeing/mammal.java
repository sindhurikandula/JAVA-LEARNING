package com.sbi.livingbeing;

public interface mammal extends animal {

	void giveBirth();
}
