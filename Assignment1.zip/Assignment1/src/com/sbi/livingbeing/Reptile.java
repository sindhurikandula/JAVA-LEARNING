package com.sbi.livingbeing;

public class Reptile implements animal {

	void layEggs() {
		System.out.println("Reptile is laying eggs....");//explicit method
	}

	@Override
	public void breathIn() {
		System.out.println("Reptile is inhaling...");//inherited method is being overridden
		
	}

	@Override
	public void breathOut() {
		System.out.println("Reptile is exhaling...");//inherited method is being overridden
		
	}

	@Override
	public void fear() {
		System.out.println("Feeling of fear..");
		
	}

	@Override
	public void eat() {
		System.out.println("eating.......");
		
	}

	@Override
	public void sleep() {
		System.out.println("sleeping.......");
		
	}

	@Override
	public void reproduction() {
		System.out.println("Reproduction.......");
		
	}

	@Override
	public void hunt() {
		System.out.println("hunting......");
		
	}

}
