package jungle.use;

import jungle.cave.Tiger;
import jungle.river.Crocodile;
public class TestProgram {
	public static void main(String[] args) {
		Crocodile croco = new Crocodile();
		croco.swim();
		Tiger t = new Tiger();
		t.roar();
	}

}
