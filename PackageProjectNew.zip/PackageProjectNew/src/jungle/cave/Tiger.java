package jungle.cave;

public class Tiger {
	public Tiger() {
		
	}
	public void roar() {
		System.out.println("Roaring tiger....");
	}
}
