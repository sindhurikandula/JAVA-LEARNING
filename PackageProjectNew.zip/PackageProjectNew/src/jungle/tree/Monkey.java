package jungle.tree;

public class Monkey {

}
