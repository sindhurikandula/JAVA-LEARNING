package jungle.tree;

import jungle.river.Crocodile;

public class Fish {
	public void swim() { 
		 Crocodile c = new Crocodile();	
	// System.out.println("Fish is swimming...");
	 System.out.println("privateA "+c.privateA);
	 System.out.println("privateA "+c.protectedB);
	 System.out.println("privateA "+c.publicC);
	 System.out.println("privateA "+c.defaultD);
		 
	 }
}
