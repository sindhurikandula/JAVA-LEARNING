package jungle.tree;

public class Chimpanzee extends Monkey {

}
