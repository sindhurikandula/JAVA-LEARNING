
class ClockTestDrive {
	public static void main(String [] args) {
		
 Time c = new Time();
 
 c.setTime("2.3");
 
 String s = c.getTime();
 
 System.out.println("time is" +s);
 }
}

class Time {
	
	String time;

	void setTime(String t) {
		time = t;
	}

	String getTime() {
		return time;
	}
}
