class fourth {
	

		public static void main(String[] args) 
		{
			System.out.println("Fourth");
		}

	}
 class fifth {
	

	public static void main(String[] args) 
	{
		System.out.println("fifth");
	}

}
 class Sixth {
	

	public static void main(String[] args) 
	{
		System.out.println("Sixth");
	}

}



