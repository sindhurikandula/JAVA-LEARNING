
class AccountOpening {

	public static void main(String args[]) {
		System.out.println("Account Opening process to be intiated");
		Customer c = new Customer();
		c.NewCustomer();
	}

}

class Customer {

	void NewCustomer() {
		System.out.println("Fill the application");
		ExistingCustomer();
	}

	void ExistingCustomer() {
		System.out.println("What is your account number");
	}
}
