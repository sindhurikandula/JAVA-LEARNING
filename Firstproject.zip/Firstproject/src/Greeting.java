
public class Greeting {

	public static void main(String[] args) {
		System.out.println("Greeting from java");
		System.out.println("welcome to world of java programming");

	}

}
