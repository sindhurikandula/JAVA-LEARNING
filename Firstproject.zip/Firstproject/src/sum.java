
public class sum {

	public static void main(String[] args) {
		int a=8;
		int b=6;
		int sum=a+b;
		System.out.println("Sum of a and b is "+sum);
		

	}

}
