
public class DataType {

	public static void main(String[] args) {
		byte b=15;
		short s=1001;
		int i=17589;
		long l=256983;
		double d=45.63;
		float f=2.3f;
		char c='A';
		
		
		System.out.println("byte value is"+b);
		System.out.println("max value of byte is" +Byte.MAX_VALUE);
		System.out.println("min value of byte is" +Byte.MIN_VALUE);
		System.out.println("size  of byte is " +Byte.SIZE+ "bits");
		
		System.out.println("short value is"+s);
		System.out.println("max value of short is" +Short.MAX_VALUE);
		System.out.println("min value of short is" +Short.MIN_VALUE);
		System.out.println("size  of short is " +Short.SIZE+ "bits");

		System.out.println("integer  is"+i);
		System.out.println("max value of intreger is" +Integer.MAX_VALUE);
		System.out.println("min value of integer is" +Integer.MIN_VALUE);
		System.out.println("size of integer is " +Integer.SIZE+ "bits");


		System.out.println("long value is"+l);
		System.out.println("max value of long is" +Long.MAX_VALUE);
		System.out.println("min value of long is" +Long.MIN_VALUE);
		System.out.println("size  of long is " +Long.SIZE+ "bits");
		
		System.out.println("float value is"+f);
		System.out.println("max value of float is" +Float.MAX_VALUE);
		System.out.println("min value of float is" +Float.MIN_VALUE);
		System.out.println("size  of floatt is " +Float.SIZE+ "bits");
		
		System.out.println("double value is"+d);
		System.out.println("max value of double is" +Double.MAX_VALUE);
		System.out.println("min value of double is" +Double.MIN_VALUE);
		System.out.println("size  of double is " +Double.SIZE+ "bits");
		
		System.out.println("charactrer  value is "+c);
		System.out.println("max value of character is" +Character.MAX_VALUE);
		System.out.println("min value of character is" +Character.MIN_VALUE);
		System.out.println("size  of character is " +Character.SIZE+ "bits");
		
		for(int index=0;index<255;index++)
		{
			
			System.out.println(index+ "charactrer  value is "+(char)index);
		}
		


	}
}
