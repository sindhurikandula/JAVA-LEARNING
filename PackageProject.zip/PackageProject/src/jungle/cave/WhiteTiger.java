package jungle.cave;

public class WhiteTiger extends Tiger {

}
