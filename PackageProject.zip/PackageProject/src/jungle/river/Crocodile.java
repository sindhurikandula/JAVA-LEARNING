package jungle.river;

public class Crocodile {

}
