package jungle.river;

public class Aligator extends Crocodile {

}
