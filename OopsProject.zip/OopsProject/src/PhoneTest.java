
public class PhoneTest {

	public static void main(String[] args) {
		Phone myPhone =new Phone();
		
		myPhone.dail();
		
		byte speedNumber=100;
		
		myPhone.dail((byte)123);
		
		myPhone.dail("sindhuri");
		
		myPhone.dail("sindhuri", "Shanvi");
		
		myPhone.dail(speedNumber,"sindhuri");
		
		myPhone.dail("sindhuri",speedNumber);
	}

}

class Phone
{
	void dail()
	{
		System.out.println("dailing no where");
	}
	
	void dail(byte speedDail)
	{
		System.out.println("dailing "+speedDail);
	}
	
	void dail(String name)
	{
		System.out.println("dailing "+name);
	}
	
	void dail(String name1,String name2)
	{
		System.out.println("dailing "+name1+" and " +name2);
	}
	
	void dail(String name1,byte b)
	{
		System.out.println("dailing "+name1+" and " +b);
	}
	void dail(byte b,String name2)
	{
		System.out.println("dailing "+b+" and " +name2);
	}
}