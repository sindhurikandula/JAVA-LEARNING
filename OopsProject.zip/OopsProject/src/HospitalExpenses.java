
public class HospitalExpenses {

	public static void main(String[] args) {

		PatientRecord p = new PatientRecord();

		p.setPatientDetails(101, "sindhuri", "Prasad");
		p.printPatientDetails();
		System.out.println("Total bill is " + p.totalBillCalc(2,"luxury",2,2000, 5000));
        System.out.println("Total bill is " + p.getTotalBill());
		System.out.println("------------");
		
		PatientRecord p2 = new PatientRecord();

		p2.setPatientDetails(102, "sameer", "raghu");
		p2.printPatientDetails();
		System.out.println("Total bill is " + p2.totalBillCalc(3,"Normal",5,2000, 5000));
        System.out.println("Total bill is " + p2.getTotalBill());
		System.out.println("------------");

	}

}

class PatientRecord {

	private int roomNumber;
	private String patientName;
	private String consultantDoctor;
	int totalBill;

	void setPatientDetails(int x, String y, String z) {
		if (x < 0)
			throw new RuntimeException("Room number cannot be negative...terminating...");
		else
			roomNumber = x;

		if (y == null) {
			throw new RuntimeException("patient name cannot be null...terminating...");
		} else

			patientName = y;

		if (z == null) {
			throw new RuntimeException("Consultant Doctor name cannot be null...terminating...");
		} else
			consultantDoctor = z;
	}

	void printPatientDetails() {
		System.out.println("Room number is " + roomNumber);
		System.out.println("Patient name is " + patientName);
		System.out.println("Consultant Doctor name is " + consultantDoctor);
		System.out.println("------------");
	}

	int totalBillCalc(int noDays,String roomType, int noTests,int amtPerTest, int miscExpns) {
		
		int roomRent;
		
		if(roomType=="luxury")
		
		roomRent =noDays*1500;
		else
	    roomRent =noDays*500;
		
		
		
		int testBill = noTests *amtPerTest ;
		
		System.out.println("No. of days stayed in the hospital " + noDays);
		System.out.println("Room Type is " + roomType);
		System.out.println("Amount of Room Rent " + roomRent);
		System.out.println("Rate per test " + amtPerTest);
		System.out.println("BIll amount pertaining to tests " + testBill);
		System.out.println("Amount of miscellaneous expenses " + miscExpns);

		totalBill = roomRent + testBill + miscExpns;
		return totalBill;

	}

	int getTotalBill() {
		return totalBill;
	}

}
