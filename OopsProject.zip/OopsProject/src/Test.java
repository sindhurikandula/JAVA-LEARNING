
public class Test {

	public static void main(String[] args) {

		Calculator calc = new Calculator();
		calc.fun1();
		
		calc.fun2(120, 50);
		
		int ans=calc.fun3(80, 50);
		System.out.println("ans is"+ans);
		System.out.println("-------------------");
		
		int value=calc.fun4();
		System.out.println("value is"+value);
		System.out.println("-------------------");
		
		
		
	}

}

class Calculator {

	public void fun1() {
		int x=20;
		int y=100;
		int z=x+y;
		System.out.println("x is"+x);
		System.out.println("y is"+y);
		System.out.println("z is"+z);
		System.out.println("-------------------");


	}
	
	public void fun2(int x,int y) {
		
		int z=x+y;
		System.out.println("x is"+x);
		System.out.println("y is"+y);
		System.out.println("z is"+z);
		System.out.println("-------------------");
	}

  public int fun3(int x,int y) {
		
		int z=x+y;
		System.out.println("x is"+x);
		System.out.println("y is"+y);
		return z;
	}
  
  public int fun4() {
		
	    int x=2;
	    int y=3;
		int z=x+y;
		System.out.println("x is"+x);
		System.out.println("y is"+y);
		return z;
	}

  
}

