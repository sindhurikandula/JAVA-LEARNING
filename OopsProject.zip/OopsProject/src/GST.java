
public class GST {

	public static void main(String[] args) {

        GstCalc calc = new GstCalc();
		calc.fun1();
		
		calc.fun2(5000, 18);
		
		double GstAmt=calc.fun3(8000,5);
		
		System.out.println("GST amt is " +GstAmt);
		System.out.println("SGST amt is " +GstAmt/2);
		System.out.println("CGST amt is " +GstAmt/2);
		System.out.println("-------------------");

		double GstAmt1=calc.fun4();
		
		System.out.println("GST amt is " +GstAmt1);
		System.out.println("SGST amt is " +GstAmt1/2);
		System.out.println("CGST amt is " +GstAmt1/2);
		System.out.println("-------------------");
		
		
	}

}

class GstCalc {

	public void fun1() {
		int invoicevalue=10000;
		int GstPercent=18;
	    double GstAmt=(GstPercent/100.0)*invoicevalue;
		System.out.println("invoicevalue is "+invoicevalue);
		System.out.println("GST percentage is "+GstPercent);
		System.out.println("GST amt is " +GstAmt);
		System.out.println("SGST amt is " +GstAmt/2);
		System.out.println("CGST amt is " +GstAmt/2);
		System.out.println("-------------------");


	}
	
	public void fun2(int invoicevalue,int GstPercent) {
		
		double GstAmt=(GstPercent/100.0)*invoicevalue;
		System.out.println("invoicevalue is "+invoicevalue);
		System.out.println("GST percentage is "+GstPercent);
		System.out.println("GST amt is " +GstAmt);
		System.out.println("SGST amt is " +GstAmt/2);
		System.out.println("CGST amt is " +GstAmt/2);
		System.out.println("-------------------");

	}

  public double fun3(int invoicevalue,int GstPercent) {
		
	    double GstAmt=(GstPercent/100.0)*invoicevalue;
		System.out.println("invoicevalue is "+invoicevalue);
		System.out.println("GST percentage is "+GstPercent);
		return GstAmt;
	}
  
  public double fun4() {
	  
	    int invoicevalue=10000;
		int GstPercent=5;
	    double GstAmt1=(GstPercent/100.0)*invoicevalue;
		System.out.println("invoicevalue is "+invoicevalue);
		System.out.println("GST percentage is "+GstPercent);
		return GstAmt1;
	    
	}

  
}

